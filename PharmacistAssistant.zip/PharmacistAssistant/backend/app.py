from flask import Flask, request, jsonify
import os
from model import analyze_medical_image
from symptom_checker import check_symptoms

app = Flask(__name__)
UPLOAD_FOLDER = "static/uploads/"
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER

# Upload & analyze medical image
@app.route("/upload", methods=["POST"])
def upload_image():
    if "file" not in request.files:
        return jsonify({"error": "No file uploaded"}), 400

    file = request.files["file"]
    filepath = os.path.join(app.config["UPLOAD_FOLDER"], file.filename)
    file.save(filepath)

    result = analyze_medical_image(filepath)
    return jsonify(result)

# Check symptoms & predict diseases
@app.route("/symptoms", methods=["POST"])
def analyze_symptoms():
    data = request.json
    symptoms = data.get("symptoms", [])
    result = check_symptoms(symptoms)
    return jsonify(result)

if __name__ == "__main__":
    app.run(debug=True)
