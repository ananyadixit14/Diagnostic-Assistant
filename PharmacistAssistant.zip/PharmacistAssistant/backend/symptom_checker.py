import pandas as pd

# Mock Data for Symptom Mapping
disease_data = {
    "Fever": ["Flu", "COVID-19"],
    "Cough": ["Bronchitis", "Pneumonia", "COVID-19"],
    "Shortness of Breath": ["Asthma", "COPD"],
    "Fatigue": ["Anemia", "Thyroid Disorder"],
}

def check_symptoms(symptoms):
    possible_conditions = set()
    for symptom in symptoms:
        if symptom in disease_data:
            possible_conditions.update(disease_data[symptom])

    return {"predicted_diseases": list(possible_conditions)}
