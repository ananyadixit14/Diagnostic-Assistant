import torch
import torchvision.transforms as transforms
from torchvision import models
from PIL import Image

# Load Pretrained Model (ResNet for X-ray classification)
model = models.resnet18(pretrained=True)
model.eval()

def analyze_medical_image(image_path):
    transform = transforms.Compose([
        transforms.Resize((224, 224)),
        transforms.ToTensor(),
    ])

    image = Image.open(image_path).convert("RGB")
    image = transform(image).unsqueeze(0)

    with torch.no_grad():
        output = model(image)

    predicted_class = torch.argmax(output).item()
    return {"diagnosis": f"Condition {predicted_class}", "confidence": float(output.max())}
