import React, { useState } from "react";
import axios from "axios";

function App() {
    const [selectedFile, setSelectedFile] = useState(null);
    const [symptoms, setSymptoms] = useState("");
    const [imageResult, setImageResult] = useState(null);
    const [symptomResult, setSymptomResult] = useState(null);

    const uploadImage = async () => {
        const formData = new FormData();
        formData.append("file", selectedFile);
        
        const response = await axios.post("http://127.0.0.1:5000/upload", formData, {
            headers: { "Content-Type": "multipart/form-data" }
        });
        setImageResult(response.data);
    };

    const checkSymptoms = async () => {
        const response = await axios.post("http://127.0.0.1:5000/symptoms", { symptoms: symptoms.split(", ") });
        setSymptomResult(response.data);
    };

    return (
        <div style={{ textAlign: "center", padding: "20px" }}>
            <h1>AI Diagnostic Assistant</h1>

            <h3>Upload Medical Image</h3>
            <input type="file" onChange={(e) => setSelectedFile(e.target.files[0])} />
            <button onClick={uploadImage}>Analyze Image</button>
            {imageResult && <p>Diagnosis: {imageResult.diagnosis} (Confidence: {imageResult.confidence.toFixed(2)})</p>}

            <h3>Enter Symptoms</h3>
            <input type="text" placeholder="e.g. Fever, Cough" value={symptoms} onChange={(e) => setSymptoms(e.target.value)} />
            <button onClick={checkSymptoms}>Check</button>
            {symptomResult && <p>Possible Diseases: {symptomResult.predicted_diseases.join(", ")}</p>}
        </div>
    );
}

export default App;
